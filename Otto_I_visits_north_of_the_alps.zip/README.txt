This ZIP container contains CSV files on Otto I's residences north of the Alps. The files can be inserted into QGis, for example, and produce an itinerary of the ruler. The recorded visits are modelled on the itinerary in Theodor Mayer, Das Deutsche Königtum und sein Wirkungsbereich, in: Das Reich und Europa. Gemeinschaftsarbeit deutscher Historiker, ed. by Theodor Mayer and Walter Platzhoff, Leipzig 1942, pp. 54-60. The reprint (1959) has been put online by the MGH: http://www.mgh-bibliothek.de/dokumente/a/a133111.pdf. The only difference to the stays mentioned there is the deletion of a "?" after Villich due to a hint from Dominik Waßenhoven (Cologne).

I hereby make these files available under the Attribution-ShareAlike (CC BY-SA) license. This means that reuse and modification is allowed under two conditions: 1. credit to the author (me) and 2.  the result must be made available under this license as well.

I hope these files help you!

If you do something cool with it, I would be happy about a hint. 

If you want to stay up to date about my work, feel free to follow me on TwiX: https://twitter.com/3mKa1 / Mastodon: @manuel_kamenzin@troet.cafe / Blue Sky: @manuel-kamenzin.bsky.social.

Last but not least: Be water, my friend!

Best
Manuel Kamenzin (November 2023)

